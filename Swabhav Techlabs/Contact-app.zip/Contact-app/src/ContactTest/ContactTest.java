package ContactTest;

import java.util.Scanner;

import Contact.Contact;

public class ContactTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		Contact c=new Contact();
		System.out.print("Select any Option:- \n1)Display Contact. \n2)Add New Contact. \n3)Delete Existing Contact. \n4)Update Contact \nChoose your option: ");
		String opt=s.nextLine();
		switch (opt) {
		  case "1":
			  System.out.println("---------------------------------------");
			  c.Display();
		    break;
		  case "2":
			  System.out.println("---------------------------------------");
			  c.AddNewContact();
		    break;
		  case "3":
			  System.out.println("---------------------------------------");
			  c.DeleteContact();
		    break;
		  case "4":
			  System.out.println("---------------------------------------");
			  c.UpdateContact();;
		    break;
		  default:
			  System.out.println("Please choose within the Given Options");
		}
	}

}
