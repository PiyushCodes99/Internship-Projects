package Contact;
import java.sql.*;
import java.util.Scanner;
public class Contact {

	public void Display() {
		Connection connection= null;
		try {
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mickey?user=root&password=root");
			
			java.sql.PreparedStatement stmt=connection.prepareStatement("Select * from Contact order by fName;");
			
			ResultSet rs=stmt.executeQuery();
			System.out.println("---------------------------------");
			System.err.println("Displaying all the Contacts :-");
			while(rs.next()) {
				System.err.println("Full-Name:- "+rs.getString(1)+" "+rs.getString(2)+" | "+"Number:- "+rs.getInt(3)+" | "+
			"Email:- "+rs.getString(4));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

	public void AddNewContact() {
		Scanner scan=new Scanner(System.in);
		System.out.print("Enter First name: ");
		String firstName=scan.nextLine();
		System.out.print("Enter Last name: ");
		String lastName=scan.nextLine();
		System.out.print("Enter Number: ");
		String Number=scan.nextLine();
		System.out.print("Enter Email: ");
		String Email=scan.nextLine();
		java.sql.Connection conn=null;
		java.sql.Statement stmt=null;
		try {
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mickey?user=root&password=root");
		stmt=conn.createStatement();
		int rows=stmt.executeUpdate("insert into Contact(fName, lName, Number, Email)\r\n"+"values("+firstName+","+lastName+","+Number +","+Email+");");
		ResultSet res=stmt.executeQuery("Select * from Contact");
		System.out.println("---------------------------------");
		System.err.println("[Successfully Added!]");
		System.out.println("---------------------------------");
		System.err.println("Displaying all the Contact After Addition");
		while(res.next()) {
			System.err.println("Full-Name:- "+res.getString(1)+" "+res.getString(2)+" | "+"Number:- "+res.getInt(3)+" | "+
		"Email:- "+res.getString(4));
		}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void DeleteContact() {
		Scanner sc=new Scanner(System.in);
		System.out.print("Please enter Name your want to Delete: ");
		String del=sc.nextLine();
		java.sql.Connection conn=null;
		java.sql.Statement stmt=null;
		ResultSet p=null;
		
		try {
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mickey?user=root&password=root");
			System.out.println("---------------------------------");
			System.err.println("[Successfully Deleted]");
			stmt=conn.createStatement();
			
			int rows=stmt.executeUpdate("Delete from Contact where Fname="+del+";");
			p=stmt.executeQuery("Select * from Contact");
			System.out.println("---------------------------------");
			System.err.println("Contacts After Deletion:-");
			while(p.next()) {
				System.err.println("Full-Name:- "+p.getString(1)+" "+p.getString(2)+" | "+"Number:- "+p.getInt(3)+" | "+
			"Email:- "+p.getString(4));
			}
		}
	catch(SQLException e) {
		e.printStackTrace();
	}
	}

	public void UpdateContact() {
		Display();
		System.out.println("------------------------------------------------------");
		Scanner sca=new Scanner(System.in);
		System.out.println("Please enter Number your want to Update: ");
		String num=sca.nextLine();
		System.out.println("Please enter the updated Name: ");
		String uptName=sca.nextLine();
		java.sql.Connection conn=null;
		java.sql.Statement stmt=null;
		ResultSet p=null;
		
		try {
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mickey?user=root&password=root");
			System.out.println("------------------------------------------------------");
			System.err.println("[Successfully Updated]");
			stmt=conn.createStatement();
			
			int rows=stmt.executeUpdate("UPDATE contact Set fName="+uptName+" WHERE NUMBER=4525;");
			
			p=stmt.executeQuery("Select * from Contact order by fName;");
			System.out.println("---------------------------------");
			System.err.println("Contacts After Updation:-");
			while(p.next()) {
				System.err.println("Full-Name:- "+p.getString(1)+" "+p.getString(2)+" | "+"Number:- "+p.getInt(3)+" | "+
			"Email:- "+p.getString(4));
			}
		}
	catch(SQLException e) {
		e.printStackTrace();
	}	
	}
}
